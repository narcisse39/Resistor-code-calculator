import java.util.ArrayList;
class generateColorValues implements resistor{
	private double firstAndSecondDigits;
	private int firstDigit;
	private int secondDigit;
	private int multiplier;
	private int tolerance;
	private int index;

	private	ArrayList<String> firstAndSecondValues = new ArrayList<String>();
	private ArrayList<String> toleranceValue = new ArrayList<String>();
	private ArrayList<String> multiplierValue = new ArrayList<String>();

	public generateColorValues() {

	}
	public generateColorValues(double firstAndSecond,int multiple,int tolValue){
		firstAndSecondDigits=firstAndSecond;
		multiplier=multiple;
		tolerance=tolValue;

}
public double firstAndSecondDigits() {
	return firstAndSecondDigits;
}
public void BandOneAndTwo(){
			if(firstAndSecondDigits() == 1 ) {
				firstDigit=0;
				secondDigit=1;
			}
			else if(firstAndSecondDigits() == 2.2 || firstAndSecondDigits() == 22 || firstAndSecondDigits() == 220) {
				firstDigit=2;
				secondDigit=2;
			}
			else if(firstAndSecondDigits() == 3.3 || firstAndSecondDigits() == 33 || firstAndSecondDigits() == 330) {
				firstDigit=3;
				secondDigit=3;
			}
			else if(firstAndSecondDigits() == 3.9 || firstAndSecondDigits() == 39|| firstAndSecondDigits() == 390) {
				firstDigit=3;
				secondDigit=9;
			}
			else if(firstAndSecondDigits() == 4.7 ||firstAndSecondDigits() == 47 || firstAndSecondDigits() == 470) {
				firstDigit=4;
				secondDigit=7;
			}
			else if(firstAndSecondDigits() == 5.6 || firstAndSecondDigits() == 56 || firstAndSecondDigits() == 560) {
				firstDigit=5;
				secondDigit=6;
			}
			else if(firstAndSecondDigits() == 6.8 || firstAndSecondDigits() == 68 || firstAndSecondDigits() == 680) {
				firstDigit=6;
				secondDigit=8;
			}
			else if(firstAndSecondDigits() == 8.2 || firstAndSecondDigits() == 82 || firstAndSecondDigits() == 820) {
				firstDigit=8;
				secondDigit=2;
			}
			else if(firstAndSecondDigits() == 10|| firstAndSecondDigits() == 100) {
				firstDigit=1;
				secondDigit=0;
			}
			else {
				firstDigit=0;
				secondDigit=0;
			}
}
public int getFirstBand() {
	return firstDigit;
}
public int getSecondBand() {
	return secondDigit;
}

public int BandThree(){

	switch(multiplier) {
	case 0:
		if((firstAndSecondDigits/10) < 1){
			multiplier= 10;
		}
		else if((firstAndSecondDigits/10) <10 || firstAndSecondDigits == 1){
			multiplier= 0;
		}
		else if((firstAndSecondDigits/10) >10){
			multiplier= 1;
		}
		break;

	case 3:
		if((firstAndSecondDigits/10) < 1 ){
			multiplier = 2;
		}
		else if((firstAndSecondDigits/10) <10 || firstAndSecondDigits == 1){
			multiplier= 3;
		}
		else if((firstAndSecondDigits/10) >10){
			multiplier= 4;
		}
		break;
	case 6:
		if((firstAndSecondDigits/10) < 1){
			multiplier = 5;
		}
		else if((firstAndSecondDigits/10) <10 || firstAndSecondDigits == 1){
			multiplier= 6;
		}
		else if((firstAndSecondDigits/10) >10){
			multiplier= 7;
		}
		break;
	default:
		break;
	}
	return multiplier;
}
public int getTolerance() {

	switch(tolerance) {
	case 1:
		index= 0;
		break;
	case 2:
		index = 1;
		break;
	case 5:
		index = 2;
		break;
	case 10:
		index =3;
		break;
	case 20:
		index =4;
		break;
	default:
		break;
	}
	return index;

}
public String toleranceValue() {
	toleranceValue.add("brown");
	toleranceValue.add("red");
	toleranceValue.add("gold");
	toleranceValue.add("silver");
	toleranceValue.add("none");

	return toleranceValue.get(getTolerance());
}
public String toString(){

	firstAndSecondValues.add("black");
	firstAndSecondValues.add("brown");
	firstAndSecondValues.add("red");
	firstAndSecondValues.add("orange");
	firstAndSecondValues.add("yellow");
	firstAndSecondValues.add("green");
	firstAndSecondValues.add("blue");
	firstAndSecondValues.add("violet");
	firstAndSecondValues.add("grey");
	firstAndSecondValues.add("white");


	multiplierValue.add("black");
	multiplierValue.add("brown");
	multiplierValue.add("red");
	multiplierValue.add("orange");
	multiplierValue.add("yellow");
	multiplierValue.add("green");
	multiplierValue.add("blue");
	multiplierValue.add("violet");
	multiplierValue.add("grey");
	multiplierValue.add("white");
	multiplierValue.add("gold");
	multiplierValue.add("silver");



	return firstAndSecondValues.get(getFirstBand())+" - "+firstAndSecondValues.get(getSecondBand()) + " - " +multiplierValue.get(BandThree());
}


	public void checkFirstColor(String firstColor){
	}
	public void checkSecondColor( String secondColor){
	}
	public void checkThirdColor(String thirdColor){
	}
	public String checkFourthColor(String fourthColor ){
		return null;
	}
	public int determineFirstTwoNumbers(){
		return 0;
	}
	public float determineE12Value(){
		return 0;
	}
	public float calculateResistorValue(){
		return 0;
	}
	public void setEngineeringNotation(){
	}
}
