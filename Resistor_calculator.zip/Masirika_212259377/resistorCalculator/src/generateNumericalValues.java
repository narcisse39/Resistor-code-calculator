
class generateNumericalValues implements resistor{

private String firstNumber;
	private String secondNumber;
	private String thirdNumber;
	private String fourthNumber;
	private String resistorVal;
	public generateNumericalValues() {

	}

	public generateNumericalValues(String firstColor, String secondColor, String thirdColor ) {
	checkFirstColor( firstColor);
	checkSecondColor( secondColor);
	checkThirdColor(thirdColor);
	}

	public void checkFirstColor(String firstColor){

		switch(firstColor){

			case "black":
				firstNumber = "0";
				break;

			case "brown":
				firstNumber = "1";
				break;

			case "red":
				firstNumber = "2";
				break;

			case "orange":
				firstNumber = "3";
				break;

			case "yellow":
				firstNumber = "4";
				break;

			case "green":
				firstNumber = "5";
				break;

			case "blue":
				firstNumber = "6";
				break;

			case "purple":
				firstNumber = "7";
				break;

			case "grey":
				firstNumber = "8";
				break;

			case "white":
				firstNumber = "9";
				break;

			default:
				System.out.println(" wrong first colour has been entered!");
				break;
			}
		}

	public void checkSecondColor( String secondColor){


		switch(secondColor){

			case "black":
				secondNumber = "0";
				break;

			case "brown":
				secondNumber = "1";
				break;

			case "red":
				secondNumber = "2";
				break;

			case "orange":
				secondNumber = "3";
				break;

			case "yellow":
				secondNumber = "4";
				break;

			case "green":
				secondNumber = "5";
				break;

			case "blue":
				secondNumber = "6";
				break;

			case "purple":
				secondNumber = "7";
				break;

			case "grey":
				secondNumber = "8";
				break;

			case "white":
				secondNumber = "9";
				break;
			default:
				System.out.println(" wrong second colour has been entered!");
				break;
		}
	}

	public void checkThirdColor(String thirdColor){

		switch(thirdColor){

			case "black":
				thirdNumber = "1";
				break;

			case "brown":
				thirdNumber = "10";
				break;

			case "red":
				thirdNumber = "100";
				break;

			case "orange":
				thirdNumber = "1000";
				break;

			case "yellow":
				thirdNumber = "10000";
				break;

			case "green":
				thirdNumber = "100000";
				break;

			case "blue":
				thirdNumber = "1000000";
				break;

			default:
				System.out.println("wrong third colour has been entered!");
				break;
			}
		}

	public String checkFourthColor(String fourthColor ){

		switch(fourthColor){

			case "brown":
				fourthNumber = "1%";
				break;

			case "red":
				fourthNumber = "2%";
				break;

			case "gold":
				fourthNumber = "5%";
				break;

			case "silver":
				fourthNumber = "10%";
				break;

			case "no color":
				fourthNumber = "20%";
				break;

			default:
				fourthNumber= "wrong fourth colour has been entered!";
				break;
			}
		return fourthNumber;
		}

	public int determineFirstTwoNumbers(){

		return Integer.parseInt(firstNumber + secondNumber);
		}

	public float determineE12Value(){

		if(determineFirstTwoNumbers() == 2)
			return (float)2.2;

		else if(determineFirstTwoNumbers() == 3)
			return (float)3.3;

		else if(determineFirstTwoNumbers() == 4)
			return (float)3.9;

		else if(determineFirstTwoNumbers() == 5)
			return (float)4.7;

		else if(determineFirstTwoNumbers() == 6)
			return (float)5.6;

		else if(determineFirstTwoNumbers() == 7)
			return (float)6.8;

		else if(determineFirstTwoNumbers() == 8)
			return (float)8.2;

		else if(determineFirstTwoNumbers() == 9)
			return (float)8.2;

		else if(determineFirstTwoNumbers() == 11)
			return (float)12;

		else if(determineFirstTwoNumbers() > 12 && determineFirstTwoNumbers() < 15){
			if(determineFirstTwoNumbers() - 12 < (15 - 12) / 2)
				return (float)12;
			else return (float)15;
			}

		else if(determineFirstTwoNumbers() > 15 && determineFirstTwoNumbers() < 18){
			if(determineFirstTwoNumbers() - 15 < (18 - 15) / 2)
				return (float)15;
			else return (float)18;
			}

		else if(determineFirstTwoNumbers() > 18 && determineFirstTwoNumbers() < 22){
			if(determineFirstTwoNumbers() - 18 < (22 - 18) / 2)
				return (float)18;
			else return (float)22;
			}

		else if(determineFirstTwoNumbers() > 22 && determineFirstTwoNumbers() < 27){
			if(determineFirstTwoNumbers() - 22 < (27 - 22) )
				return (float)22;
			else return (float)27;
			}

		else if(determineFirstTwoNumbers() > 27 && determineFirstTwoNumbers() < 33){
			if(determineFirstTwoNumbers() - 27 < (33 - 27) / 2)
				return (float)27;
			else return (float)33;
			}

		else if(determineFirstTwoNumbers() > 33 && determineFirstTwoNumbers() < 39){
			if(determineFirstTwoNumbers() - 33 < (39 - 33) / 2)
				return (float)33;
			else return (float)39;
			}

		else if(determineFirstTwoNumbers() > 39 && determineFirstTwoNumbers() < 47){
			if(determineFirstTwoNumbers() - 39 < (47 - 39) / 2)
				return (float)39;
			else return (float)47;
			}

		else if(determineFirstTwoNumbers() > 47 && determineFirstTwoNumbers() < 56){
			if(determineFirstTwoNumbers() - 47 < (56 - 47) / 2)
				return (float)47;
			else return (float)56;
			}

		else if(determineFirstTwoNumbers() > 56 && determineFirstTwoNumbers() < 68){
			if(determineFirstTwoNumbers() - 56 < (68 - 56) / 2)
				return (float)56;
			else return (float)68;
			}

		else if(determineFirstTwoNumbers() > 68 && determineFirstTwoNumbers() < 82){
			if(determineFirstTwoNumbers() - 68 < (82 - 68) / 2)
				return (float)68;
			else return (float)82;
			}

		else if(determineFirstTwoNumbers() > 82 && determineFirstTwoNumbers() < 100){
			if(determineFirstTwoNumbers() - 82 < (100 - 82) / 2)
				return (float)82;
			else return (float)100;
			}

		else return determineFirstTwoNumbers();
		}

	public float calculateResistorValue(){

		return determineE12Value() * Integer.parseInt(thirdNumber);
		}

	public void setEngineeringNotation(){

		if(calculateResistorValue() < 1000)
			resistorVal = String.valueOf(calculateResistorValue()) + " Ohms";

		else if(calculateResistorValue() >= 1000 && calculateResistorValue() < 1000000)
			resistorVal = String.valueOf((float)calculateResistorValue() / 1000) + " KOhms";

		else if(calculateResistorValue() >= 1000000 && calculateResistorValue() < 1000000000)
			resistorVal = String.valueOf((float)calculateResistorValue() / 1000000) + " MOhms";

		else
			resistorVal = String.valueOf((float)calculateResistorValue() / 1000000000) + " GOhms";
		}

	public String toString(){
		return resistorVal;
	}

	// Overridden methods to implement the interface resistor
	public double firstAndSecondDigits(){
		return 0;
	}
	public void BandOneAndTwo(){
	}
	public int getFirstBand(){
		return 0;
	}
	public int getSecondBand(){
		return 0;
	}
	public int BandThree(){
		return 0;
	}
	public int getTolerance(){
		return 0;
	}
	public String toleranceValue() {
		return null;
	}
}
