import javax.swing.JFrame;
public class resistorCalculator {

    public static void main(String[] args) {
	Menu menu = new Menu();
	menu.setVisible(true);

    }
}
