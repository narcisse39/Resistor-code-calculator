import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import java.awt.Font;
import javax.swing.JTextField;
import javax.swing.JOptionPane;

class Menu extends JFrame{
	private JPanel contentPane;

	private int firstState=0;
	private int secondState=0;
	private int valueOfTolerance;
	private int valueOfMultiplier;

	private JLabel labelFirstBand;
	private JLabel labelSecondBand;
	private JLabel labelThirdBand;
	private JLabel labelFourthBand;
	private JLabel labelNearestResistanceValue;
	private JLabel labelResistorColorCodes;
	private JLabel labelGenerateColorValues;
	private JLabel labelFirstTwoDigits;
	private JLabel labelMultiplier;
	private JLabel labelTolerance;
	private JLabel labelGenerateNumericalValues;

	private JButton btnFirstBand;
	private JButton btnSecondBand;
	private JButton btnThirdBand;
	private JButton btnFourthBand;
	private JButton btnGenerateNumericalValues;
	private JButton btnGenerateColorValues;

	private String colorResistanceValue;
	private String colorToleranceValue;
	private String colorValueBand1;
	private String colorValueBand2;
	private String colorValueBand3;
	private String colorValueBand4;

	private JComboBox comboBoxTolerance;
	private JComboBox comboBoxMultiplier;

	private String[] ToleranceOfResistor = {"1%","2%","5%","10%","20%"};
	private String[] multiplierValueOfResistor = {"Ohms","KOhms","MOhms"};
	private int[] multiplierPower = {0,3,6};
	private int[] toleranceValue = {1,2,5,10,20};

	private JTextField textFieldNearestResistanceValue;
	private JTextField textFieldEnterResistanceValue;
	private JTextField textFieldResistorColorCodes;
	private JTextField textFieldToleranceColorValue;
	private JTextField textFieldToleranceNumericalValue;


	public Menu() {
		super("Resistor calculator");
		contentPane = new JPanel();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 578, 350);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);


	windowContent();
	}

	public void windowContent(){
		//The user will select the color code the click on submit to generate the nearest e12 resistance values
		labelGenerateNumericalValues = new JLabel("GENERATE NUMERICAL VALUES");
		labelGenerateNumericalValues.setFont(new Font("Serif", Font.BOLD +Font.ITALIC, 13));
		labelGenerateNumericalValues.setBounds(27, 11, 214, 23);
		contentPane.add(labelGenerateNumericalValues);

		labelFirstBand = new JLabel("First Band");
		labelFirstBand.setFont(new Font("Serif", Font.BOLD+Font.ITALIC, 13));
		labelFirstBand.setBounds(27, 45, 62, 16);
		contentPane.add(labelFirstBand);

		labelSecondBand = new JLabel("Second Band");
		labelSecondBand.setFont(new Font("Serif", Font.BOLD+Font.ITALIC, 13));
		labelSecondBand.setBounds(123, 46, 89, 15);
		contentPane.add(labelSecondBand);

		labelThirdBand = new JLabel("Multiplier Band");
		labelThirdBand.setFont(new Font("Serif", Font.BOLD+Font.ITALIC, 12));
		labelThirdBand.setBounds(233, 46, 89, 14);
		contentPane.add(labelThirdBand);

		labelFourthBand = new JLabel("Tolerance Band");
		labelFourthBand.setFont(new Font("Serif", Font.BOLD+Font.ITALIC, 13));
		labelFourthBand.setBounds(343, 46, 89, 15);
		contentPane.add(labelFourthBand);

		labelNearestResistanceValue = new JLabel("Nearest resistance values");
		labelNearestResistanceValue.setFont(new Font("Serif", Font.BOLD+Font.ITALIC, 13));
		labelNearestResistanceValue.setBounds(165, 122, 154, 18);
		labelNearestResistanceValue.setToolTipText("Display resistance values - Tolerance value");
		contentPane.add(labelNearestResistanceValue);

		textFieldNearestResistanceValue = new JTextField();
		textFieldNearestResistanceValue.setBounds(345, 122, 96, 19);
		textFieldNearestResistanceValue.setColumns(12);
		contentPane.add(textFieldNearestResistanceValue);

		textFieldToleranceNumericalValue = new JTextField();
		textFieldToleranceNumericalValue.setBounds(449, 122, 47, 19);
		textFieldToleranceNumericalValue.setColumns(10);
		contentPane.add(textFieldToleranceNumericalValue);

		btnFirstBand = new JButton("Band1");
		btnFirstBand.setFont(new Font("Serif", Font.BOLD, 16));
		btnFirstBand.setBackground(Color.MAGENTA);
		btnFirstBand.setToolTipText("Select the color for the first Band");
		btnFirstBand.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event)
			{


			changeOfState(btnFirstBand);
			colorValueBand1=getColorValue();
			}
		}
		);
		btnFirstBand.setBounds(27, 82, 79, 23);
		contentPane.add(btnFirstBand);

		btnSecondBand = new JButton("Band2");
		btnSecondBand.setFont(new Font("Serif", Font.BOLD, 16));
		btnSecondBand.setBackground(Color.MAGENTA);
		btnSecondBand.setToolTipText("Select the color for the second Band");
		btnSecondBand.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event)
			{
				changeOfState(btnSecondBand);
				colorValueBand2 = getColorValue();
			}
		}
		);
		btnSecondBand.setBounds(123, 82, 89, 23);
		contentPane.add(btnSecondBand);

		btnThirdBand = new JButton("Band3");
		btnThirdBand.setFont(new Font("Serif", Font.BOLD, 16));
		btnThirdBand.setBackground(Color.MAGENTA);
		btnThirdBand.setToolTipText("Select the color for the multiplier Band");
		btnThirdBand.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event)
			{
			changeOfState(btnThirdBand);
			colorValueBand3=getColorValue();
			}
		}
		);
		btnThirdBand.setBounds(233, 82, 89, 23);
		contentPane.add(btnThirdBand);

		btnFourthBand = new JButton("Band4");
		btnFourthBand.setFont(new Font("Serif", Font.BOLD, 16));
		btnFourthBand.setBackground(Color.MAGENTA);
		btnFourthBand.setToolTipText("Select the color for the tolerance Band");
		btnFourthBand.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event)
			{
			changeOfToleranceState(btnFourthBand);
				colorValueBand4=getColorOfToleranceValue();
			}
		}
		);
		btnFourthBand.setBounds(343, 82, 89, 23);
		contentPane.add(btnFourthBand);

		btnGenerateNumericalValues = new JButton("SUBMIT");
		btnGenerateNumericalValues.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			try{
				resistor	numericalValue = new generateNumericalValues(colorValueBand1,colorValueBand2,colorValueBand3);
				numericalValue.determineFirstTwoNumbers();
				numericalValue.determineE12Value();
				numericalValue.calculateResistorValue();
				numericalValue.setEngineeringNotation();
				textFieldNearestResistanceValue.setText(numericalValue.toString());
				textFieldToleranceNumericalValue.setText(numericalValue.checkFourthColor(colorValueBand4));
			}catch(Exception e) {
				JOptionPane.showMessageDialog( null, "Please select resistance\nvalues for all bands!","Error message", JOptionPane.PLAIN_MESSAGE );

				}

			}
		});
		btnGenerateNumericalValues.setFont(new Font("Serif", Font.BOLD, 15));
		btnGenerateNumericalValues.setBounds(442, 78, 96, 33);
		contentPane.add(btnGenerateNumericalValues);

		//The user will enter the resistance values,select the multiplier and tolerance values from  drop down lists
		labelGenerateColorValues = new JLabel("GENERATE COLOR VALUES");
		labelGenerateColorValues.setFont(new Font("Serif", Font.BOLD+Font.ITALIC, 13));
		labelGenerateColorValues.setBounds(27, 152, 214, 23);
		contentPane.add(labelGenerateColorValues);

		labelFirstTwoDigits = new JLabel("Enter values");
		labelFirstTwoDigits.setToolTipText("Enter the values for the first and second digits");
		labelFirstTwoDigits.setFont(new Font("Serif", Font.BOLD+Font.ITALIC, 14));
		labelFirstTwoDigits.setBounds(27, 186, 86, 15);
		contentPane.add(labelFirstTwoDigits);

		labelMultiplier = new JLabel("Multiplier");
		labelMultiplier.setToolTipText("Select the value for the multiplier");
		labelMultiplier.setFont(new Font("Serif",Font.BOLD+Font.ITALIC , 14));
		labelMultiplier.setBounds(123, 186, 70, 17);
		contentPane.add(labelMultiplier);

		labelTolerance = new JLabel("Tolerance");
		labelTolerance.setToolTipText("Select the value for the tolerance");
		labelTolerance.setFont(new Font("Serif", Font.BOLD+Font.ITALIC, 14));
		labelTolerance.setBounds(217, 187, 77, 17);
		contentPane.add(labelTolerance);

		labelResistorColorCodes = new JLabel("Resistor color codes");
		labelResistorColorCodes.setFont(new Font("Serif", Font.BOLD+Font.ITALIC, 13));
		labelResistorColorCodes.setBounds(165, 254, 129, 23);
		labelResistorColorCodes.setToolTipText("Display resistance color values - Tolerance color value");
		contentPane.add(labelResistorColorCodes);

		textFieldResistorColorCodes = new JTextField();
		textFieldResistorColorCodes.setBounds(305, 255, 140, 22);
		textFieldResistorColorCodes.setColumns(12);
		contentPane.add(textFieldResistorColorCodes);

		textFieldToleranceColorValue = new JTextField();
		textFieldToleranceColorValue.setBounds(454, 254, 72, 23);
		textFieldToleranceColorValue.setColumns(12);
		contentPane.add(textFieldToleranceColorValue);

		textFieldEnterResistanceValue = new JTextField();
		textFieldEnterResistanceValue.setBounds(27, 212, 70, 23);
		textFieldEnterResistanceValue.setColumns(10);
		contentPane.add(textFieldEnterResistanceValue);

		comboBoxTolerance = new JComboBox(ToleranceOfResistor);
		comboBoxTolerance.setMaximumRowCount( 3 );
		comboBoxTolerance.setBounds(215, 212, 79, 23);
		comboBoxTolerance.setToolTipText("Select the value of the tolerance");
		comboBoxTolerance.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event)
			{
				valueOfTolerance = toleranceValue[comboBoxTolerance.getSelectedIndex()];
			}
		}
		);
		contentPane.add(comboBoxTolerance);

		comboBoxMultiplier = new JComboBox(multiplierValueOfResistor);
		 comboBoxMultiplier.setMaximumRowCount( 3 );
		comboBoxMultiplier.setBounds(123, 212, 70, 23);
		comboBoxMultiplier.setToolTipText("Select the value of the multiplier");
		comboBoxMultiplier.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent event)
			{
				valueOfMultiplier = multiplierPower[comboBoxMultiplier.getSelectedIndex()];
			}
		}
		);
		contentPane.add(comboBoxMultiplier);

		btnGenerateColorValues = new JButton("SUBMIT");
		btnGenerateColorValues.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				int valueResistance;
				try {
					 valueResistance = Integer.parseInt(textFieldEnterResistanceValue.getText());

					resistor colorValues = new generateColorValues(valueResistance,valueOfMultiplier,valueOfTolerance);
					colorValues.BandOneAndTwo();
					colorValues.getFirstBand();
					colorValues.getSecondBand();
					colorValues.BandThree();
					colorValues.getTolerance();
					textFieldResistorColorCodes.setText(colorValues.toString());
					textFieldToleranceColorValue.setText(colorValues.toleranceValue());


				}catch(Exception e) {
				JOptionPane.showMessageDialog( null, "Please enter resistance values!","Error message", JOptionPane.PLAIN_MESSAGE );

				}

			}
		});
		btnGenerateColorValues.setFont(new Font("Serif", Font.BOLD, 15));
		btnGenerateColorValues.setBounds(304, 203, 106, 39);
		contentPane.add(btnGenerateColorValues);


	}
	public void changeOfState(JButton colorValue) {

		switch(firstState)
		{
			case 0:
				colorValue.setBackground(Color.BLACK);
				colorResistanceValue = "black";

				break;
			case 1:
				colorValue.setBackground(new Color(153,102,51));
				colorResistanceValue = "brown";
				break;
			case 2:
				colorValue.setBackground(Color.RED);
				colorResistanceValue = "red";
				break;
			case 3:
				colorValue.setBackground(new Color(255,140,0));
				colorResistanceValue = "orange";
				break;
			case 4:
				colorValue.setBackground(Color.YELLOW);
				colorResistanceValue = "yellow";
				break;
			case 5:
				colorValue.setBackground(Color.GREEN);
				colorResistanceValue = "green";
				break;
			case 6:
				colorValue.setBackground(Color.BLUE);
				colorResistanceValue = "blue";
				break;
			case 7:
				colorValue.setBackground(new Color(204,102,204));
				colorResistanceValue = "purple";
				break;
			case 8:
				colorValue.setBackground(Color.GRAY);
				colorResistanceValue = "grey";
				break;
			case 9:
				colorValue.setBackground(Color.WHITE);
				colorResistanceValue = "white";
				break;
		}
		firstState++; //move to the next color in the sequence
		firstState %= 10; // Make sure to remain within the sequence
	}
	public String getColorValue() {
		return colorResistanceValue;
		}

	public void changeOfToleranceState(JButton color) {

		switch(secondState)
		{
			case 0:
			color.setBackground(new Color(153,102,51));
				colorToleranceValue = "brown";

				break;
			case 1:
				color.setBackground(Color.RED);
				colorToleranceValue = "red";
				break;
			case 2:
				color.setBackground(Color.YELLOW);
				colorToleranceValue= "gold";
				break;
			case 3:
				color.setBackground(Color.GRAY);
				colorToleranceValue = "silver";
				break;
			case 4:
				color.setBackground(Color.WHITE);
				colorToleranceValue = "no color";
				break;

		}
		secondState++; //move to the next color in the sequence
		secondState %= 5; // Make sure to remain within the sequence
	}
	public String getColorOfToleranceValue() {
		return colorToleranceValue;
		}

}
