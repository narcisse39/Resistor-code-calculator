
public interface resistor {
	public double firstAndSecondDigits();
	public void BandOneAndTwo();
	public int getFirstBand();
	public int getSecondBand();
	public int BandThree();
	public int getTolerance();
	public String toleranceValue() ;
	public void checkFirstColor(String firstColor);
	public void checkSecondColor( String secondColor);
	public void checkThirdColor(String thirdColor);
	public String checkFourthColor(String fourthColor );
	public int determineFirstTwoNumbers();
	public float determineE12Value();
	public float calculateResistorValue();
	public void setEngineeringNotation();

}
